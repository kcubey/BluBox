
## Text Recognition for Android using Google Mobile Vision.

This is a sample project for tutorial found here
[TextRecognition](https://medium.com/@prakash_pun/text-recognition-for-android-using-google-mobile-vision-a8ffabe3f5d6)
